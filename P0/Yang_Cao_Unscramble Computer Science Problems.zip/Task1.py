"""
Read file into texts and calls.
It's ok if you don't understand how to read files.
"""
import csv
with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)


with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)

unique = []

def add_to_unique(x, unique):
    if x in unique:
        pass
    else:
        unique.append(x)


[add_to_unique(text[0], unique) for text in texts]
[add_to_unique(text[1], unique) for text in texts]
[add_to_unique(call[0], unique) for call in calls]
[add_to_unique(call[1], unique) for call in calls]

print("There are {} different telephone numbers in the records".format(len(unique)))


"""
TASK 1:
How many different telephone numbers are there in the records? 
Print a message:
"There are <count> different telephone numbers in the records."
"""
